#!/bin/bash

ANEXO="$1"

#CALLFILE="/srv/www/htdocs/tmp/llamar_${ANEXO}.call"
CALLFILE="/tmp/llamar_${ANEXO}.call"

cat <<EOF > "$CALLFILE"
Channel: PJSIP/${ANEXO}
MaxRetries: 0
RetryTime: 60
WaitTime: 30
Context: confirmacion-citas
Extension: s
Priority: 1
CallerID: "Llamante" <113>
EOF

mv "$CALLFILE" /var/spool/asterisk/outgoing/
