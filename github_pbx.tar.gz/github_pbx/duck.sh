#cronta -ñ
#*/1 * * * * ~/duckdns/duck.sh >/dev/null 2>&1

#rolejo-pbx.duckdns.org
echo url="https://www.duckdns.org/update?domains=rolejo-pbx&token=c9819c77-e9e3-4ea1-bb82-20138155e174&ip=" | curl -k -o ~/duckdns/duck.log -K -
