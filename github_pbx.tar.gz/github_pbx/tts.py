#!/usr/bin/env python3

import os
import sys
import subprocess
from urllib.parse import parse_qs
from gtts import gTTS
from pydub import AudioSegment

print("Content-Type: text/plain\n")

try:
    content_length = int(os.environ.get("CONTENT_LENGTH", 0))
    post_data = sys.stdin.read(content_length)

    params = parse_qs(post_data)

    mensaje = params.get("mensaje", [""])[0].strip()
    anexo = params.get("anexo", ["113"])[0].strip()  # default 113

    if not mensaje:
        raise Exception("Mensaje vacío")

    base_path = "/var/lib/asterisk/sounds/custom"
    mp3_file = f"{base_path}/mensaje_tts.mp3"
    wav_file = f"{base_path}/mensaje_tts.wav"

    # 1. TTS
    tts = gTTS(mensaje, lang="es")
    tts.save(mp3_file)

    # 2. Conversión a formato telefónico
    audio = AudioSegment.from_file(mp3_file, format="mp3")
    audio = audio.set_frame_rate(8000).set_channels(1).set_sample_width(2)
    #audio.export(wav_file, format="wav")
    audio.export(wav_file, format="wav", codec="pcm_s16le")

    # 3. Ejecutar llamada con anexo dinámico
    subprocess.run(["/usr/lib/cgi-bin/gen_call.sh", anexo], check=True)

    print("OK")
    print(f"Mensaje: {mensaje}")
    print(f"Anexo: {anexo}")
    print(f"Audio: {wav_file}")

except Exception as e:
    print("ERROR")
    print(str(e))
