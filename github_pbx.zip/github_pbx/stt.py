#!/usr/bin/env python3

import os
from pydub import AudioSegment
import speech_recognition as sr

print("Content-Type: text/plain\n")

try:
    mp3_path = "/var/lib/asterisk/sounds/custom/mensaje_tts.mp3"
    wav_path = "/tmp/audio_stt_tmp.wav"

    if not os.path.exists(mp3_path):
        raise Exception("No existe mensaje_tts.mp3, genera el TTS primero")

    audio = AudioSegment.from_mp3(mp3_path)
    audio = audio.set_frame_rate(16000).set_channels(1).set_sample_width(2)
    audio.export(wav_path, format="wav")

    r = sr.Recognizer()
    with sr.AudioFile(wav_path) as source:
        audio_data = r.record(source)

    texto = r.recognize_google(audio_data, language="es-CL")

    os.remove(wav_path)

    print(texto)

except Exception as e:
    print("ERROR")
    print(str(e))
