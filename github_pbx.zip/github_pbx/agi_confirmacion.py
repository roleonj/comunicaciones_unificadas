#!/usr/bin/env python3

from asterisk.agi import AGI, AGIHangup
import csv
import logging
from datetime import datetime

CSV_PATH = "/var/lib/asterisk/agi-bin/citas.csv"
MAX_INTENTOS = 3

logging.basicConfig(
    filename="/var/log/asterisk/confirmacion_citas.log",
    level=logging.INFO,
    format="%(asctime)s %(message)s"
)

agi = AGI()
agi.answer()

channel = agi.env.get("agi_channel", "")
anexo = channel.split("/")[1].split("-")[0] if "/" in channel else "desconocido"

logging.info(f"Llamada iniciada - Anexo: {anexo}")
agi.verbose(f"CONFIRMACION-CITAS: Llamada iniciada - Anexo: {anexo}", 1)

estado = "sin_respuesta"

try:
    digito = ""
    intentos = 0

    while intentos < MAX_INTENTOS:
        intentos += 1

        digito = agi.stream_file("custom/mensaje_tts", escape_digits="123")

        if not digito:
            digito = agi.wait_for_digit(5000)
            digito = digito.strip() if digito else ""

        if digito in ("1", "2", "3"):
            break

        if digito == "":
            logging.info(f"Anexo {anexo} intento {intentos}: sin respuesta (silencio)")
            agi.verbose(f"CONFIRMACION-CITAS: Anexo {anexo} silencio, intento {intentos}", 1)
            continue

        logging.info(f"Anexo {anexo} intento {intentos}: opcion invalida ('{digito}')")
        agi.verbose(f"CONFIRMACION-CITAS: Anexo {anexo} opcion invalida '{digito}', intento {intentos}", 1)
        agi.stream_file("custom/opcion_invalida")

    estados = {"1": "confirmada", "2": "cancelada", "3": "reprogramar"}
    mensajes_cierre = {
        "1": "custom/cita_confirmada",
        "2": "custom/cita_cancelada",
        "3": "custom/cita_reprogramada",
    }

    if digito in ("1", "2", "3"):
        estado = estados[digito]
        logging.info(f"Anexo {anexo} presiono: '{digito}'")
        agi.verbose(f"CONFIRMACION-CITAS: Anexo {anexo} presiono '{digito}'", 1)
        agi.stream_file(mensajes_cierre[digito])
    else:
        estado = "sin_respuesta"
        logging.info(f"Anexo {anexo} sin respuesta valida tras {MAX_INTENTOS} intentos")
        agi.verbose(f"CONFIRMACION-CITAS: Anexo {anexo} sin respuesta valida tras {MAX_INTENTOS} intentos", 1)

    agi.stream_file("custom/despedida")

    filas = []
    with open(CSV_PATH, newline="") as f:
        reader = csv.DictReader(f)
        campos = reader.fieldnames
        for fila in reader:
            if fila["anexo"] == anexo:
                fila["estado"] = estado
                fila["fecha_confirmacion"] = datetime.now().isoformat()
            filas.append(fila)

    with open(CSV_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=campos)
        writer.writeheader()
        writer.writerows(filas)

    logging.info(f"Anexo {anexo} actualizado a estado: {estado}")
    agi.verbose(f"CONFIRMACION-CITAS: Anexo {anexo} actualizado a estado: {estado}", 1)

except AGIHangup:
    logging.warning(f"Anexo {anexo}: el llamante colgó durante la interacción")
    agi.verbose(f"CONFIRMACION-CITAS: Anexo {anexo} colgó antes de completar", 1)

except Exception as e:
    logging.error(f"Error en AGI anexo {anexo}: {str(e)}")
    agi.verbose(f"CONFIRMACION-CITAS: ERROR anexo {anexo}: {str(e)}", 1)

finally:
    try:
        agi.hangup()
    except Exception:
        pass